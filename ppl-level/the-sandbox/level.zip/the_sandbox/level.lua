-- Sandbox by Tasty Kiwi

pewpew.set_level_size(450fx, 450fx)
local ship = pewpew.new_player_ship(225fx, 150fx, 0)
pewpew.configure_player(0, {camera_distance = 50fx, shield = 0})
pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_6, cannon = pewpew.CannonType.SINGLE})

local background = pewpew.new_customizable_entity(0fx, 0fx)
pewpew.customizable_entity_set_mesh(background, "/dynamic/graphics.lua", 0)
pewpew.customizable_entity_set_mesh_scale(background, 450fx)

-- You should add custom variables here
local other = {
    session = 1,

    mothership_amount = 1,
    asteroid_amount = 1,
    baf_amount = 10,
    crowder_amount = 2,
    cube_amount = 1,
    wary_amount = 2,
    inertiac_amount = 1,
    sphere_amount = 1,
    ufo_amount = 2,

    weapon_type = 0,
    weapon_freq = 8,
    shield_amount = 2,
    levelsize = 450
}

local ui = {
    pewpew.new_customizable_entity(225fx, 225fx), -- level id
    pewpew.new_customizable_entity(125fx, 225fx), -- <-
    pewpew.new_customizable_entity(325fx, 225fx), -- ->
    pewpew.new_customizable_entity(225fx, 325fx)  -- step (starts with Mothership:)
}

function begin_play(mothership_amount, asteroid_amount, baf_amount, crowder_amount, cube_amount, wary_amount, inertiac_amount, sphere_amount, ufo_amount, weapon_type, weapon_freq, shield_amount, levelsize)
    -- remove lobby completely, run a selected level
    pewpew.configure_player_ship_weapon(ship, {})
    for i = 1, #ui do
        pewpew.entity_destroy(ui[i])
    end
    for i = 1, #other do
        table.remove(other, i)
    end
    pewpew.set_level_size(10fx, 10fx)
    pewpew.entity_destroy(background)
    pewpew.entity_set_position(ship, 0fx, 0fx)
    pewpew.entity_destroy(ship)
    require("/dynamic/levels/main_level.lua")(mothership_amount, asteroid_amount, baf_amount, crowder_amount, cube_amount, wary_amount, inertiac_amount, sphere_amount, ufo_amount, weapon_type, weapon_freq, shield_amount, fmath.to_fixedpoint(levelsize))
end


--pewpew.entity_set_radius(ui[1], 28fx)
pewpew.customizable_entity_set_mesh_scale(ui[1], 0.3072fx)
pewpew.customizable_entity_set_string(ui[1], other.mothership_amount)
pewpew.customizable_entity_set_string(ui[2], "<<<")
pewpew.customizable_entity_set_string(ui[3], ">>>")
pewpew.customizable_entity_set_string(ui[4], "Motherships:")

for i = 1, #ui do
    pewpew.entity_set_radius(ui[i], 28fx)
end

function handle_decrease(item_name, step, min)
    other[item_name] = other[item_name] - step
    if other[item_name] < min then
        other[item_name] = min
    end
    if other.session == 10 then
        handle_weapon_type()
    elseif other.session == 11 then
        handle_weapon_freq()
    else
        pewpew.customizable_entity_set_string(ui[1], other[item_name])
    end
end

function handle_increase(item_name, step, max)
    other[item_name] = other[item_name] + step
    if other[item_name] > max then
        other[item_name] = max
    end
    if other.session == 10 then
        handle_weapon_type()
    elseif other.session == 11 then
        handle_weapon_freq()
    else
        pewpew.customizable_entity_set_string(ui[1], other[item_name])
    end
end

function handle_weapon_type()
    if other.weapon_type == pewpew.CannonType.SINGLE then
        pewpew.customizable_entity_set_string(ui[1], "Single")
    elseif other.weapon_type == pewpew.CannonType.TIC_TOC then
        pewpew.customizable_entity_set_string(ui[1], "Tic Toc")
    elseif other.weapon_type == pewpew.CannonType.DOUBLE then
        pewpew.customizable_entity_set_string(ui[1], "Double")
    elseif other.weapon_type == pewpew.CannonType.TRIPLE then
        pewpew.customizable_entity_set_string(ui[1], "Triple")
    elseif other.weapon_type == pewpew.CannonType.FOUR_DIRECTIONS then
        pewpew.customizable_entity_set_string(ui[1], "Four Direct.")
    elseif other.weapon_type == pewpew.CannonType.DOUBLE_SWIPE then
        pewpew.customizable_entity_set_string(ui[1], "Double Swipe")
    elseif other.weapon_type == pewpew.CannonType.HEMISPHERE then
        pewpew.customizable_entity_set_string(ui[1], "Hemisphere")
    end
end

function handle_weapon_freq()
    if other.weapon_freq == pewpew.CannonFrequency.FREQ_1 then
        pewpew.customizable_entity_set_string(ui[1], "1 Hz")
    elseif other.weapon_freq == pewpew.CannonFrequency.FREQ_2 then
        pewpew.customizable_entity_set_string(ui[1], "2 Hz")
    elseif other.weapon_freq == pewpew.CannonFrequency.FREQ_3 then
        pewpew.customizable_entity_set_string(ui[1], "3 Hz")
    elseif other.weapon_freq == pewpew.CannonFrequency.FREQ_5 then
        pewpew.customizable_entity_set_string(ui[1], "5 Hz")
    elseif other.weapon_freq == pewpew.CannonFrequency.FREQ_6 then
        pewpew.customizable_entity_set_string(ui[1], "6 Hz")
    elseif other.weapon_freq == pewpew.CannonFrequency.FREQ_7_5 then
        pewpew.customizable_entity_set_string(ui[1], "7.5 Hz")
    elseif other.weapon_freq == pewpew.CannonFrequency.FREQ_10 then
        pewpew.customizable_entity_set_string(ui[1], "10 Hz")
    elseif other.weapon_freq == pewpew.CannonFrequency.FREQ_15 then
        pewpew.customizable_entity_set_string(ui[1], "15 Hz")
    elseif other.weapon_freq == pewpew.CannonFrequency.FREQ_30 then
        pewpew.customizable_entity_set_string(ui[1], "30 Hz")
    end
end

pewpew.customizable_entity_set_weapon_collision_callback(ui[1], function(entity_id, player_index, weapon_type)
    if weapon_type == pewpew.WeaponType.BULLET then
        if other.session == 1 then
            other.session = 2
            pewpew.customizable_entity_set_string(ui[4], "Asteroids:")
            pewpew.customizable_entity_set_string(ui[1], other["asteroid_amount"])
        elseif other.session == 2 then
            other.session = 3
            pewpew.customizable_entity_set_string(ui[4], "BAFs:")
            pewpew.customizable_entity_set_string(ui[1], other["baf_amount"])
        elseif other.session == 3 then
            other.session = 4
            pewpew.customizable_entity_set_string(ui[4], "Crowders:")
            pewpew.customizable_entity_set_string(ui[1], other["crowder_amount"])
        elseif other.session == 4 then
            other.session = 5
            pewpew.customizable_entity_set_string(ui[4], "Rolling cubes:")
            pewpew.customizable_entity_set_string(ui[1], other["cube_amount"])
        elseif other.session == 5 then
            other.session = 6
            pewpew.customizable_entity_set_string(ui[4], "Waries:")
            pewpew.customizable_entity_set_string(ui[1], other["wary_amount"])
        elseif other.session == 6 then
            other.session = 7
            pewpew.customizable_entity_set_string(ui[4], "Inertiacs:")
            pewpew.customizable_entity_set_string(ui[1], other["inertiac_amount"])
        elseif other.session == 7 then
            other.session = 8
            pewpew.customizable_entity_set_string(ui[4], "Rolling Spheres:")
            pewpew.customizable_entity_set_string(ui[1], other["sphere_amount"])
        elseif other.session == 8 then
            other.session = 9
            pewpew.customizable_entity_set_string(ui[4], "UFOs:")
            pewpew.customizable_entity_set_string(ui[1], other["ufo_amount"])
        elseif other.session == 9 then
            other.session = 10
            pewpew.customizable_entity_set_string(ui[4], "Weapon type:")
            handle_weapon_type()
        elseif other.session == 10 then
            other.session = 11
            pewpew.customizable_entity_set_string(ui[4], "Weapon frequency:")
            handle_weapon_freq()
        elseif other.session == 11 then
            other.session = 12
            pewpew.customizable_entity_set_string(ui[4], "Shields:")
            pewpew.customizable_entity_set_string(ui[1], other["shield_amount"])
        elseif other.session == 12 then
            other.session = 13
            pewpew.customizable_entity_set_string(ui[4], "Level size:")
            pewpew.customizable_entity_set_string(ui[1], other["levelsize"])
        elseif other.session == 13 then
            begin_play(other["mothership_amount"], other["asteroid_amount"], other["baf_amount"], other["crowder_amount"], other["cube_amount"], other["wary_amount"], other["inertiac_amount"], other["sphere_amount"], other["ufo_amount"], other["weapon_type"], other["weapon_freq"], other["shield_amount"], other["levelsize"])
        end
    end
    return true
end)

pewpew.customizable_entity_set_weapon_collision_callback(ui[2], function(entity_id, player_index, weapon_type)
    if weapon_type == pewpew.WeaponType.BULLET then
        if other.session == 1 then
            handle_decrease("mothership_amount", 1, 0)
        elseif other.session == 2 then
            handle_decrease("asteroid_amount", 1, 0)
        elseif other.session == 3 then
            handle_decrease("baf_amount", 10, 0)
        elseif other.session == 4 then
            handle_decrease("crowder_amount", 2, 0)
        elseif other.session == 5 then
            handle_decrease("cube_amount", 1, 0)
        elseif other.session == 6 then
            handle_decrease("wary_amount", 2, 0)
        elseif other.session == 7 then
            handle_decrease("inertiac_amount", 1, 0)
        elseif other.session == 8 then
            handle_decrease("sphere_amount", 1, 0)
        elseif other.session == 9 then
            handle_decrease("ufo_amount", 2, 0)
        elseif other.session == 10 then
            handle_decrease("weapon_type", 1, 0)
        elseif other.session == 11 then
            handle_increase("weapon_freq", 1, 8)
        elseif other.session == 12 then
            handle_decrease("shield_amount", 2, 0)
        elseif other.session == 13 then
            handle_decrease("levelsize", 50, 150)
        end
    end
    return true
end)


pewpew.customizable_entity_set_weapon_collision_callback(ui[3], function(entity_id, player_index, weapon_type)
    if weapon_type == pewpew.WeaponType.BULLET then
        if other.session == 1 then
            handle_increase("mothership_amount", 1, 20)
        elseif other.session == 2 then
            handle_increase("asteroid_amount", 1, 15)
        elseif other.session == 3 then
            handle_increase("baf_amount", 10, 100)
        elseif other.session == 4 then
            handle_increase("crowder_amount", 2, 30)
        elseif other.session == 5 then
            handle_increase("cube_amount", 1, 35)
        elseif other.session == 6 then
            handle_increase("wary_amount", 2, 30)
        elseif other.session == 7 then
            handle_increase("inertiac_amount", 1, 7)
        elseif other.session == 8 then
            handle_increase("sphere_amount", 1, 12)
        elseif other.session == 9 then
            handle_increase("ufo_amount", 2, 10)
        elseif other.session == 10 then
            handle_increase("weapon_type", 1, 6)
        elseif other.session == 11 then
            handle_decrease("weapon_freq", 1, 0)
        elseif other.session == 12 then
            handle_increase("shield_amount", 2, 100)
        elseif other.session == 13 then
            handle_increase("levelsize", 50, 1000)
        end
    end
    return true
end)
