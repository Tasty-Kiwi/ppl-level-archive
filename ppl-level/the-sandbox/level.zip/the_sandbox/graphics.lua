meshes = {{
  vertexes = {{0,0}, {0,1}, {1,1}, {1,0}},
  segments = {{0,1,2,3,0}},
  colors = {0xff00ffff, 0xffff00ff, 0x00ff00ff, 0x0000ffff}
}}