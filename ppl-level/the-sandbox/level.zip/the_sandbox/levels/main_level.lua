-- Sandbox by Tasty Kiwi

return function(mothership_amount, asteroid_amount, baf_amount, crowder_amount, cube_amount, wary_amount, inertiac_amount, sphere_amount, ufo_amount, weapon_type, weapon_freq, shield_amount, levelsize)


    local width = levelsize
    local height = width
    pewpew.set_level_size(width, height)
    local background = pewpew.new_customizable_entity(0fx, 0fx)
    pewpew.customizable_entity_set_mesh(background, "/dynamic/graphics.lua", 0)
    pewpew.customizable_entity_set_mesh_scale(background, width)
    local ship = pewpew.new_player_ship(width / 2fx, height / 2fx, 0)
    pewpew.configure_player(0, {shield = shield_amount})
    pewpew.configure_player_ship_weapon(ship, {frequency = weapon_freq, cannon = weapon_type})

    pewpew.add_update_callback(function()
        if pewpew.get_entity_count(pewpew.EntityType.MOTHERSHIP) == 0 then
            for i = 1, mothership_amount do
                pewpew.new_mothership(fmath.random_fixedpoint(0fx, width), fmath.random_fixedpoint(0fx, height), fmath.random_int(0, 4), fmath.random_fixedpoint(0fx, fmath.tau()))
            end
        end
        if pewpew.get_entity_count(pewpew.EntityType.ASTEROID) == 0 then
            for i = 1, asteroid_amount do
                pewpew.new_asteroid(fmath.random_fixedpoint(0fx, width), fmath.random_fixedpoint(0fx, height))
            end
        end
        if pewpew.get_entity_count(pewpew.EntityType.BAF) == 0 then
            for i = 1, baf_amount do
                pewpew.new_baf(fmath.random_fixedpoint(0fx, width), fmath.random_fixedpoint(0fx, height), fmath.random_fixedpoint(0fx, fmath.tau()), 15fx, -1)
            end
        end
        if pewpew.get_entity_count(pewpew.EntityType.CROWDER) == 0 then
            for i = 1, crowder_amount do
                pewpew.new_crowder(fmath.random_fixedpoint(0fx, width), fmath.random_fixedpoint(0fx, height))
            end
        end
        if pewpew.get_entity_count(pewpew.EntityType.ROLLING_CUBE) == 0 then
            for i = 1, cube_amount do
                pewpew.new_rolling_cube(fmath.random_fixedpoint(0fx, width), fmath.random_fixedpoint(0fx, height))
            end
        end
        if pewpew.get_entity_count(pewpew.EntityType.WARY) == 0 then
            for i = 1, wary_amount do
                pewpew.new_wary(fmath.random_fixedpoint(0fx, width), fmath.random_fixedpoint(0fx, height))
            end
        end
        if pewpew.get_entity_count(pewpew.EntityType.INERTIAC) == 0 then
            for i = 1, inertiac_amount do
                pewpew.new_inertiac(fmath.random_fixedpoint(0fx, width), fmath.random_fixedpoint(0fx, height), 1.819fx, fmath.random_fixedpoint(0fx, fmath.tau()))
            end
        end
        if pewpew.get_entity_count(pewpew.EntityType.ROLLING_SPHERE) == 0 then
            for i = 1, sphere_amount do
                pewpew.new_rolling_sphere(fmath.random_fixedpoint(0fx, width), fmath.random_fixedpoint(0fx, height), fmath.random_fixedpoint(0fx, fmath.tau()), 7fx)
            end
        end
        if pewpew.get_entity_count(pewpew.EntityType.UFO) == 0 then
            for i = 1, ufo_amount do
                pewpew.ufo_set_enable_collisions_with_walls(pewpew.new_ufo(fmath.random_fixedpoint(0fx, width), fmath.random_fixedpoint(0fx, height), 2fx), true)
            end
        end
        if pewpew.entity_get_is_alive(ship) == false then
            pewpew.stop_game()
        end
    end)


end