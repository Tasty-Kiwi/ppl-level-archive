local angle_helpers = require("/dynamic/helpers/angle_helpers.lua")
local player_helpers = require("/dynamic/helpers/player_helpers.lua")
local floating_message = require("/dynamic/helpers/floating_message.lua")
local shield_box = require("/dynamic/helpers/boxes/shield_box.lua")
local cannon_box = require("/dynamic/helpers/boxes/cannon_box.lua")

local width = 314fx
local height = 314fx
pewpew.set_level_size(width, height)

local background = pewpew.new_customizable_entity(0fx, 0fx)
pewpew.customizable_entity_set_mesh(background, "/dynamic/graphics.lua", 0)

local main_label = pewpew.new_customizable_entity(width / 2fx, height / 2fx + 80fx)
pewpew.customizable_entity_set_string(main_label, "Happy Pi Day!")

local sec_label = pewpew.new_customizable_entity(width / 2fx, height / 2fx)
pewpew.customizable_entity_set_string(sec_label, "Did you know? (Restart to see more!)")
local thi_label = pewpew.new_customizable_entity(width / 2fx, height / 2fx - 30fx)
local rng = fmath.random_int(1, 5)
if rng == 1 then
  pewpew.customizable_entity_set_string(thi_label, "Pi has infinite loops!")
elseif rng == 2 then
  pewpew.customizable_entity_set_string(thi_label, "fmath.tau() is 2 * pi!")
elseif rng == 3 then
  pewpew.customizable_entity_set_string(thi_label, "Value of Pi is about 22 / 7!")
elseif rng == 4 then
  pewpew.customizable_entity_set_string(thi_label, "Pi's decimal digits never end!")
elseif rng == 5 then
  pewpew.customizable_entity_set_string(thi_label, "Pi was calculated first by Archimedes!")
end
-- Create players
local weapon_config = {frequency = pewpew.CannonFrequency.FREQ_7_5, cannon = pewpew.CannonType.FOUR_DIRECTIONS}
local ship = player_helpers.new_player_ship(31.4fx, 31.4fx, 0)
pewpew.configure_player(0, {camera_distance = 50fx, shield = 3})
pewpew.configure_player_ship_weapon(ship, weapon_config)


local function random_position()
  return fmath.random_fixedpoint(10fx, width-10fx), fmath.random_fixedpoint(10fx, height-10fx)
end
local time = 0
pewpew.add_update_callback(
    function()
      if pewpew.entity_get_is_alive(ship) == true then
        time = time + 1
        local modulo = time % 100
        if modulo == 0 then
          local x,y = random_position()
          shield_box.new(x, y, weapon_config)
        end
        if modulo == 33 then
          local x, y = random_position()
          pewpew.new_rolling_cube(0fx, 0fx)
          pewpew.new_rolling_cube(0fx, height)
          pewpew.new_rolling_cube(width, height)
          pewpew.new_rolling_cube(width, 0fx)
        end
      else
        pewpew.stop_game()
      end
    end)
