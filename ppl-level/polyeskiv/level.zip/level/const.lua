return {
    WIDTH_INT = 1000,
    HEIGHT_INT = 500,

    WIDTH = 1000fx,
    HEIGHT = 500fx,

    SPAWN_X = 500fx,
    SPAWN_Y = 250fx
}