local bullets = {}

function bullets.new_bullets(x, y, type)
  pewpew.entity_react_to_weapon(pewpew.new_mothership(x, y, type, 0fx), {type = pewpew.WeaponType.ATOMIZE_EXPLOSION, x = x, y = y, player_index = 0})
end

return bullets