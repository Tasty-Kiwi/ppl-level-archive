local const = require("/dynamic/const.lua")
local floating_message = require("/dynamic/helpers/floating_message.lua")
local bullets = require("/dynamic/mship_bullet.lua")
local eskiv_boxes = require("/dynamic/eskiv_boxes/eskiv_boxes.lua")
local shield_box = require("/dynamic/helpers/boxes/shield_box.lua")

pewpew.set_level_size(const.WIDTH, const.HEIGHT)
local bg = pewpew.new_customizable_entity(0fx, 0fx)
pewpew.customizable_entity_set_mesh(bg, "/dynamic/bg.lua", 0)

pewpew.configure_player(0, { shield = 7 })
local ship = pewpew.new_player_ship(const.SPAWN_X, const.SPAWN_Y, 0)
pewpew.configure_player_ship_weapon(ship, {frequency = pewpew.CannonFrequency.FREQ_5, cannon = pewpew.CannonType.SINGLE})

local difficulty = 0
local ticks = 0
pewpew.add_update_callback(function()
  ticks = ticks + 1
  if pewpew.get_player_configuration(0)["has_lost"] == true then
    pewpew.stop_game()
  end

  if ticks % 300 == 0 and difficulty < 20 then
    difficulty = difficulty + 1
    local sx, sy = pewpew.entity_get_position(ship)
    floating_message.new(sx, sy + 20fx, "Difficulty increased", 0.2048fx, 0xff7f00ff, 4)
    pewpew.print(difficulty)
  end

  if ticks > 50 and ticks % (30 - difficulty) == 0 then
    local rng_number = fmath.random_int(0, 4)
    if fmath.random_int(0, 9) == 9 then
      pewpew.new_mothership(fmath.random_fixedpoint(0fx, const.WIDTH), fmath.random_fixedpoint(0fx, const.HEIGHT), rng_number, fmath.random_fixedpoint(0fx, fmath.tau()))
    else
      bullets.new_bullets(fmath.random_fixedpoint(0fx, const.WIDTH), fmath.random_fixedpoint(0fx, const.HEIGHT), rng_number)
    end
    -- local custom_color = 0
    -- if rng_number == 0 then
    --   -- 3 corners
    --   custom_color = 0xbe1f64ff
    -- elseif rng_number == 1 then
    --   -- 4 corners
    --   custom_color = 0xff0000ff
    -- elseif rng_number == 2 then
    --   -- 5 corners
    --   custom_color = 0xc74b00ff
    -- elseif rng_number == 3 then
    --   -- 6 corners
    --   custom_color = 0x00ff00ff
    -- elseif rng_number == 4 then
    --   -- 7 corners
    --   custom_color = 0x00f6c1ff
    -- end
    -- pewpew.customizable_entity_set_mesh_color(bg, custom_color)
  end

  if ticks % 150 == 0 then
    eskiv_boxes.create_box(fmath.random_fixedpoint(0fx, const.WIDTH - 50fx), fmath.random_fixedpoint(0fx, const.HEIGHT - 50fx), 10, nil, function(time_delta, player_index, ship_id)
      pewpew.increase_score_of_player(player_index, time_delta * 45)
    end)
  end
  if ticks % 400 == 0 then
    shield_box.new(fmath.random_fixedpoint(0fx, const.WIDTH - 50fx), fmath.random_fixedpoint(0fx, const.HEIGHT - 50fx))
  end
end)