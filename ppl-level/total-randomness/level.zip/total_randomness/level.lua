local Brownian = require("/dynamic/assets/brownian.lua")
local color_lib = require("/dynamic/assets/color_helpers.lua")
-- create level size

width = fmath.to_fixedpoint(fmath.random_int(1, 6000))
height = fmath.to_fixedpoint(fmath.random_int(1, 6000))
pewpew.set_level_size(width, height)

-- Func for color gen

function get_random_color()
  return color_lib.make_color(fmath.random_int(0, 255), fmath.random_int(0, 255), fmath.random_int(0, 255), fmath.random_int(0, 255))
end

-- configure background

local background = pewpew.new_customizable_entity(0fx, 0fx)
pewpew.customizable_entity_set_mesh(background, "/dynamic/assets/border.lua", 0)
pewpew.customizable_entity_set_mesh_xyz_scale(background, width, height, 1fx)
pewpew.customizable_entity_configure_music_response(background, {color_start = get_random_color(), color_end = get_random_color(), scale_z_start = fmath.random_fixedpoint(0.2048fx, 1fx), scale_z_end = fmath.random_fixedpoint(1fx, 3fx)})


-- create player

local weapon_config = {frequency = fmath.random_int(0, 9), cannon = fmath.random_int(0, 6)}
local ship = pewpew.new_player_ship(fmath.random_fixedpoint(1fx, width), fmath.random_fixedpoint(1fx, height), 0)
pewpew.configure_player(0, {camera_distance = fmath.random_fixedpoint(1fx, 750fx), shield = fmath.random_int(0, 31), move_joystick_color = get_random_color(), shoot_joystick_color = get_random_color()})
pewpew.set_player_ship_speed(ship, 0fx, fmath.random_fixedpoint(0fx, 38fx), -1)

-- add 20% chance to not get any weapon

if fmath.random_int(0, 4) < 4 then
  pewpew.configure_player_ship_weapon(ship, weapon_config)
end

-- add 25% chance to get rotated camera

local camera_id = fmath.random_int(-1, 3)
if camera_id == 2 then
  pewpew.configure_player(0, { camera_rotation_x_axis = -1fx * fmath.random_fixedpoint(0fx, fmath.tau())})
elseif camera_id == 3 then
  pewpew.configure_player(0, { camera_rotation_x_axis = fmath.random_fixedpoint(0fx, fmath.tau())})
end

-- generating entities

function generate_enemy(id, _x, _y)
  if id == 1 then
    pewpew.new_mothership(_x, _y, fmath.random_int(0, 4), fmath.random_fixedpoint(0fx, fmath.tau()))
  elseif id == 2 then
    pewpew.new_asteroid(_x, _y)
  elseif id == 3 then
    pewpew.new_baf(_x, _y, fmath.random_fixedpoint(1fx, 6fx), fmath.random_fixedpoint(1fx, 25fx), fmath.random_int(-1, 1800))
  elseif id == 4 then
    pewpew.new_inertiac(_x, _y, fmath.random_fixedpoint(1fx, 3fx), fmath.random_fixedpoint(0fx, fmath.tau()))
  elseif id == 5 then
    pewpew.new_rolling_cube(_x, _y)
  elseif id == 6 then
    pewpew.new_wary(_x, _y)
  elseif id == 7 then
    pewpew.new_rolling_sphere(_x, _y, fmath.random_fixedpoint(0fx, fmath.tau()), fmath.random_fixedpoint(1fx, 15fx))
  elseif id == 8 then
    pewpew.ufo_set_enable_collisions_with_walls(pewpew.new_ufo(_x, _y, fmath.random_fixedpoint(1fx, 5fx)), true)
  elseif id == 9 then
    pewpew.new_crowder(_x, _y)
  elseif id == 10 then
    Brownian.new(_x, _y, ship)
  elseif id == 11 then
    pewpew.new_baf_blue(_x, _y, fmath.random_fixedpoint(1fx, 6fx), fmath.random_fixedpoint(1fx, 25fx), fmath.random_int(-1, 1800))
  elseif id == 12 then
    pewpew.entity_react_to_weapon(pewpew.new_rolling_sphere(_x, _y, fmath.random_fixedpoint(0fx, fmath.tau()), fmath.random_fixedpoint(12fx, 25fx)), {type = pewpew.WeaponType.FREEZE_EXPLOSION, x = _x, y = _y, player_index = 0})
  elseif id == 13 then
    pewpew.new_bomb(_x, _y, fmath.random_int(0, 3))
  elseif id == 14 then
    pewpew.new_baf_red(_x, _y, fmath.random_fixedpoint(1fx, 6fx), fmath.random_fixedpoint(1fx, 25fx), fmath.random_int(-1, 1800))
  end
end

function generate_mess()
  local entity_count = fmath.random_int(1, 30)
  -- debug function to show entity creation

  --pewpew.print("Entities created: " .. entity_count)
  for i = 0, entity_count do
    generate_enemy(fmath.random_int(1, 14), fmath.random_fixedpoint(0fx, width), fmath.random_fixedpoint(0fx, height))
  end
end

-- check if all entities are gone

--[[
function check_all_entities()
  return pewpew.get_entity_count(pewpew.EntityType.MOTHERSHIP) + pewpew.get_entity_count(pewpew.EntityType.ASTEROID) + pewpew.get_entity_count(pewpew.EntityType.BAF) + pewpew.get_entity_count(pewpew.EntityType.INERTIAC) + pewpew.get_entity_count(pewpew.EntityType.ROLLING_CUBE) + pewpew.get_entity_count(pewpew.EntityType.WARY) + pewpew.get_entity_count(pewpew.EntityType.UFO) + pewpew.get_entity_count(pewpew.EntityType.CROWDER) + pewpew.get_entity_count(pewpew.EntityType.CUSTOMIZABLE_ENTITY) - 1
end
]]

-- check if game is over or all entities were killed

local time = 0
local time_modulo = fmath.random_int(30, 300)
pewpew.print("Map width: " .. width .. "fx, height: " .. height .. "fx; Time modulo: " .. time_modulo .. " ticks (" .. time_modulo / 30 .. " seconds); camera_id: " .. camera_id)
generate_mess()
pewpew.add_update_callback(
    function()
        if pewpew.get_player_configuration(0)["has_lost"] == true then
          pewpew.stop_game()
        end
        time = time + 1
        if time % time_modulo == 0 then
          generate_mess()
        end
    end)
