computed_vertexes = {}
computed_segments = {}
computed_colors = {}

local color_lib = require("/dynamic/assets/color_helpers.lua")

function get_rand_color()
  return color_lib.make_color(math.random(0, 255), math.random(0, 255), math.random(0, 255), math.random(0, 255))
end

function get_random_color()
  local color_set = {get_rand_color(), get_rand_color()}
  return color_set[math.random(1, #color_set)]
end

local w = 1
local h = 1

local index1 = 0
local index2 = 1
local index3 = 2
local index4 = 3
for z=-200, 200, math.random(25, 75) do
  table.insert(computed_vertexes, {0,0,z})
  table.insert(computed_vertexes, {w,0,z})
  table.insert(computed_vertexes, {w,h,z})
  table.insert(computed_vertexes, {0,h,z})
  table.insert(computed_segments, {index1, index2, index3, index4, index1})
  index1 = index1 + 4
  index2 = index2 + 4
  index3 = index3 + 4
  index4 = index4 + 4

  table.insert(computed_colors, get_random_color())
  table.insert(computed_colors, get_random_color())
  table.insert(computed_colors, get_random_color())
  table.insert(computed_colors, get_random_color())
end

meshes = {
  {
    vertexes = computed_vertexes,
    segments = computed_segments,
    colors = computed_colors
  }
}


