-- ---------------------------------- --
-- ------ Sounds for: Deadline ------ --
-- ------ by: SKPG, Tasty Kiwi ------ --
-- ---------------------------------- --

sounds = {
  {
    frequency = 1000,
    decay = 0.5,
    waveform = "breaker",
  },
  {
    frequency = 500,
    decay = 0.5,
    waveform = "triangle",
  }
}
