meshes = {
  {
    vertexes = {{0,0},{0,1000},{1000,1000},{1000,0}},
    segments = {{0,1,2,3,0}},
    colors = {math.random(0x00000000, 0xffffff00) + 0x00000066, math.random(0x00000000, 0xffffff00) + 0x00000066, math.random(0x00000000, 0xffffff00) + 0x00000066, math.random(0x00000000, 0xffffff00) + 0x00000066}
  }
}