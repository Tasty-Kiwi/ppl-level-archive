require "/dynamic/pplaf/pplaf.lua"

local play = player.create(START_POS_X, START_POS_Y)
pewpew.configure_player(0, { shield = 2 })
pewpew.configure_player_ship_weapon(play, { frequency = pewpew.CannonFrequency.FREQ_1, cannon = pewpew.CannonType.HEMISPHERE, duration = 99999999 })

local bg = pewpew.new_customizable_entity(0fx, 0fx)
pewpew.customizable_entity_set_mesh(bg, "/dynamic/GFX.lua", 0)

local bg2 = pewpew.new_customizable_entity(0fx, 0fx)
pewpew.customizable_entity_set_mesh(bg2, "/dynamic/GFX2.lua", 0)

function random_pos()
  return fxmath.random(0fx, LEVEL_WIDTH), fxmath.random(0fx, LEVEL_HEIGHT)
end

pewpew.add_update_callback(function()
  if GAME_STATE then
    if pewpew.get_player_configuration(0).has_lost then
      stop_game()
    end
    TIME = TIME + 1
    player.main()
    camera.main()
    --[[if TIME % 150 == 0 and chance(50) then
      local px, py = pewpew.entity_get_position(play)
      floating_message.new(px, py, "You were lucky enough to get a shield!", 0.2048fx, 0xffff00ff, 1)
      pewpew.configure_player(0, {shield = pewpew.get_player_configuration(0).shield + 1})
    end]]
    if TIME % 7 == 0 then
      local x, y = random_pos()
      local rnd = math.random(0, 4)
      if rnd == 0 then
        pewpew.new_baf_blue(x, y, fxmath.random(0fx, fmath.tau()), 10fx, 450)
      elseif rnd == 1 then
        pewpew.new_baf(x, y, fxmath.random(0fx, fmath.tau()), 10fx, 450)
      elseif rnd == 2 then
        pewpew.new_baf_red(x, y, fxmath.random(0fx, fmath.tau()), 10fx, 450)
      elseif rnd == 3 then
        pewpew.new_crowder(x, y)
      elseif rnd == 4 then
        pewpew.new_rolling_cube(x, y)
      end
    end
  end
end)