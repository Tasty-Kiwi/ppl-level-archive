
meshes = {
	{
	vertexes = {{-10, 0}, {0, 10}, {10, 0}, {0, -10}},
	segments = {{0, 1, 2, 3, 0}},
	  colors = {0xff333399, 0xff333399, 0xff333399, 0xff333399}
	}
}