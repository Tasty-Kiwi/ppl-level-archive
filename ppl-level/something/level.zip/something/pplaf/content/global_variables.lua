
PI = 3.141592654
TAU = PI * 2
BIG_NUMBER = fmath.to_int(fmath.max_fixedpoint())
PI_FX = fmath.tau() / 2fx
TAU_FX = fmath.tau()
BIG_FX = fmath.max_fixedpoint()

LEVEL_WIDTH  = 1000fx
LEVEL_HEIGHT = 1000fx

START_POS_X = LEVEL_WIDTH / 2fx
START_POS_Y = LEVEL_HEIGHT / 2fx
TIME = 0
GAME_STATE = true

NULL_FUNCTION = function() end
