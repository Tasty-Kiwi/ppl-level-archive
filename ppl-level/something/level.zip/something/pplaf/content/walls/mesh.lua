
meshes = {
	{
	vertexes = {{0, 0}, {100, 0}},
	segments = {{0, 1}}
	},
}