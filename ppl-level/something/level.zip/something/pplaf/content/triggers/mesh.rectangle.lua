
local a = 100

meshes = {
	{
		vertexes = {{a, a}, {a, -a}, {-a, -a}, {-a, a}},
		segments = {{0, 1, 2, 3, 0}}
	},
}