
meshes = {
	{
	vertexes = {{20, 2}, {10, 12}, {-10, 12}, {0, 2},
				{7, -2}, {0, -9}, {-14, -9}, {-7, -2},
				{-6, 2}, {-11, 7}, {-21, 7}, {-16, 2}},
	segments = {{0, 1, 2, 3, 0}, {4, 5, 6, 7, 4}, {8, 9, 10, 11, 8}},
	  colors = {0x33ff33ff, 0x33ff33ff, 0x33ff33ff, 0x33ff33ff,
				0x55ee77ff, 0x55ee77ff, 0x55ee77ff, 0x55ee77ff,
				0x77ddbbff, 0x77ddbbff, 0x77ddbbff, 0x77ddbbff}
	},
}