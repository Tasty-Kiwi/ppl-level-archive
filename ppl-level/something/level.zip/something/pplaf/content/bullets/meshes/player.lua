
meshes = {
	{
	vertexes = {{-7, 4}, {7, 0}, {-7, -4}},
	segments = {{0, 1, 2}},
	colors   = {0x39ff39ff, 0x39ff39ff, 0x39ff39ff}
	},
}