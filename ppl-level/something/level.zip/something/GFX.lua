meshes = {
  {
    vertexes = {},
    segments = {},
    colors = {}
  }
}

function AddSegmentsToMesh(mesh, vertexes, colors)
  vertex_count = #mesh.vertexes
  new_vertex_count = #vertexes
  if new_vertex_count % 2 ~= 0 then
    pewpew.print("Error: array's size should be even.")
    return
  end

  for i = 1, new_vertex_count do
    table.insert(mesh.vertexes, vertexes[i])
    table.insert(mesh.colors, colors[i])
  end

  for i = 0, new_vertex_count - 1, 2 do
    table.insert(mesh.segments, {vertex_count + i, vertex_count + i + 1})
  end
end

local vertexes = {}
local colors = {}

local width = 1000
local height = 1000
local margin = 0

-- 7976 for 6000fx
-- 750 for 1500fx
-- 250 for 750fx
for i = 0, 500 do
  local x = math.random(margin, width - margin)
  local y = math.random(margin, height - margin)
  local z = math.random(-400, -55)
  table.insert(vertexes, {x, y, z})
  table.insert(vertexes, {x + math.random(-50, 50), y + math.random(-50, 50), z + math.random(-50, 50)})
  --table.insert(colors, 0xffffff00 + math.random(1, 255))
  --table.insert(colors, 0xffffff00 + math.random(1, 255))
  table.insert(colors, math.random(0x00000000, 0xffffffff))
  table.insert(colors, math.random(0x00000000, 0xffffffff))
end

AddSegmentsToMesh(meshes[1], vertexes, colors)