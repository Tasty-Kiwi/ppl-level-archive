local floating_message = require("/dynamic/floating_message.lua")
-- Set level size and make border mesh.
local w = 1250fx
local h = 1000fx

local border = pewpew.new_customizable_entity(0fx, 0fx)
pewpew.customizable_entity_start_spawning(border, 90)
pewpew.customizable_entity_set_mesh(border, "/dynamic/level_graphics.lua", 0)

local border2 = pewpew.new_customizable_entity(1000fx, 0fx)
pewpew.customizable_entity_set_mesh(border2, "/dynamic/graphics1.lua", 0)

local border3 = pewpew.new_customizable_entity(2000fx, 0fx)
pewpew.customizable_entity_set_mesh(border3, "/dynamic/graphics1.lua", 0)

local border4 = pewpew.new_customizable_entity(3000fx, 0fx)
pewpew.customizable_entity_set_mesh(border4, "/dynamic/graphics1.lua", 0)

local border5 = pewpew.new_customizable_entity(4000fx, 0fx)
pewpew.customizable_entity_set_mesh(border5, "/dynamic/graphics1.lua", 0)

local border6 = pewpew.new_customizable_entity(5000fx, 0fx)
pewpew.customizable_entity_set_mesh(border6, "/dynamic/graphics1.lua", 0)
-- Configure player and a simple HUD.
pewpew.configure_player(0, {camera_distance=-750fx, camera_rotation_x_axis = fmath.tau() / -18fx, shield = 3})
local ship = pewpew.new_player_ship(w / 2fx, h / 2fx, 0)
pewpew.configure_player_ship_weapon(ship, { frequency = pewpew.CannonFrequency.FREQ_1, cannon = pewpew.CannonType.SINGLE})

local inv1 = pewpew.new_customizable_entity(pewpew.entity_get_position(ship))
pewpew.customizable_entity_set_position_interpolation(inv1, true)

local inv2 = pewpew.new_customizable_entity(pewpew.entity_get_position(ship))
pewpew.customizable_entity_set_position_interpolation(inv2, true)

local money_counter = pewpew.new_customizable_entity(pewpew.entity_get_position(ship))
pewpew.customizable_entity_set_position_interpolation(money_counter, true)

local plus1 = pewpew.new_customizable_entity(1125fx, 500fx)
pewpew.customizable_entity_set_string(plus1, "+")
pewpew.customizable_entity_set_mesh_scale(plus1, 5fx)
pewpew.entity_set_radius(plus1, 10fx)

local plus2 = pewpew.new_customizable_entity(2125fx, 500fx)
pewpew.customizable_entity_set_string(plus2, "+")
pewpew.customizable_entity_set_mesh_scale(plus2, 5fx)
pewpew.entity_set_radius(plus2, 10fx)

local plus3 = pewpew.new_customizable_entity(3125fx, 500fx)
pewpew.customizable_entity_set_string(plus3, "+")
pewpew.customizable_entity_set_mesh_scale(plus3, 5fx)
pewpew.entity_set_radius(plus3, 10fx)

local plus4 = pewpew.new_customizable_entity(4125fx, 500fx)
pewpew.customizable_entity_set_string(plus4, "+")
pewpew.customizable_entity_set_mesh_scale(plus4, 5fx)
pewpew.entity_set_radius(plus4, 10fx)

local plus5 = pewpew.new_customizable_entity(5125fx, 500fx)
pewpew.customizable_entity_set_string(plus5, "+")
pewpew.customizable_entity_set_mesh_scale(plus5, 5fx)
pewpew.entity_set_radius(plus5, 10fx)
-- Assign some variables.
local time = 0
local stone = 0
local wood = 0
local tree_amount = 50 --fmath.random_int(10, 30)
local tree_leaves = {}
local tree_barks = {}
local tree_x = {}
local tree_y = {}
local tree_uses = {}
local rock_amount = 50--fmath.random_int(10, 30)
local rocks = {}
local rock_x = {}
local rock_y = {}
local rock_uses = {}
local money = 100000
-- Generate random ammount of trees.
function generatetrees(start_x, start_y, end_x, end_y)
    for i=1, tree_amount do
        table.insert(tree_x, fmath.random_fixedpoint(start_x, end_x))
        table.insert(tree_y, fmath.random_fixedpoint(start_y, end_y))
        table.insert(tree_leaves, pewpew.new_customizable_entity(tree_x[i], tree_y[i]))
        pewpew.customizable_entity_start_spawning(tree_leaves[i], 120)
        pewpew.customizable_entity_set_mesh(tree_leaves[i], "/dynamic/tree.lua", 0)
        pewpew.customizable_entity_set_mesh_scale(tree_leaves[i], 100fx)
        pewpew.customizable_entity_set_mesh_color(tree_leaves[i], 0x228B22AA)
        table.insert(tree_barks, pewpew.new_customizable_entity(tree_x[i], tree_y[i]))
        pewpew.customizable_entity_start_spawning(tree_barks[i], 120)
        pewpew.customizable_entity_set_mesh(tree_barks[i], "/dynamic/tree.lua", 1)
        pewpew.customizable_entity_set_mesh_scale(tree_barks[i], 100fx)
        pewpew.customizable_entity_set_mesh_color(tree_barks[i], 0xCD853FFF)
        pewpew.entity_set_radius(tree_barks[i], 30fx)
        table.insert(tree_uses, 0)
    end
end
function generaterocks(start_x, start_y, end_x, end_y)
    for i=1, rock_amount do
        table.insert(rock_x, fmath.random_fixedpoint(start_x, end_x))
        table.insert(rock_y, fmath.random_fixedpoint(start_y, end_y))
        table.insert(rocks, pewpew.new_customizable_entity(rock_x[i], rock_y[i]))
        pewpew.customizable_entity_start_spawning(rocks[i], 120)
        pewpew.customizable_entity_set_mesh(rocks[i], "/dynamic/rock.lua", 0)
        pewpew.customizable_entity_set_mesh_scale(rocks[i], 20fx)
        pewpew.customizable_entity_set_mesh_color(rocks[i], 0x353535FF)
        pewpew.entity_set_radius(rocks[i], 30fx)
        table.insert(rock_uses, 0)
    end
end
generatetrees(0fx, 0fx, w-250fx, h)
generaterocks(0fx, 0fx, w-250fx, h)
pewpew.add_update_callback(
function()
        if pewpew.entity_get_is_alive(ship) then
            pewpew.set_level_size(w, h)
            -- Code for changing location of HUD.
            local x, y = pewpew.entity_get_position(ship)
            pewpew.entity_set_position(money_counter, x, y + 40fx)
            pewpew.customizable_entity_set_string(money_counter, "$" ..  money)
            pewpew.entity_set_position(inv1, x, y - 40fx)
            pewpew.customizable_entity_set_string(inv1, "#CD853FFFWood: " .. wood)
            pewpew.entity_set_position(inv2, x, y - 80fx)
            pewpew.customizable_entity_set_string(inv2, "#696969FFStone: " .. stone)
            -- Code for detecting bullets for trees.
            for i=1, tree_amount do
                if pewpew.entity_get_is_alive(tree_leaves[i]) and pewpew.entity_get_is_alive(tree_barks[i]) then
                    pewpew.customizable_entity_set_weapon_collision_callback(tree_barks[i], function(entity_id, player_index, weapon_type)
                    if weapon_type == pewpew.WeaponType.BULLET and pewpew.entity_get_is_alive(tree_leaves[i]) and pewpew.entity_get_is_alive(entity_id) then
                        pewpew.create_explosion(tree_x[i], tree_y[i], 0xCD853FFF, 1fx, 15)
                        wood = wood + 1
                        money = money + 15
                        tree_uses[i] = tree_uses[i] + 1
                        end
                        -- If tree is attacked 5 times, destroy it.
                        if weapon_type == pewpew.WeaponType.BULLET and tree_uses[i] == 5 and pewpew.entity_get_is_alive(tree_leaves[i]) and pewpew.entity_get_is_alive(entity_id) then
                            --pewpew.customizable_entity_start_exploding(tree_leaves[i], 30)
                            --pewpew.customizable_entity_start_exploding(entity_id, 30)
                            pewpew.entity_destroy(tree_leaves[i])
                            pewpew.entity_destroy(entity_id)
                            pewpew.create_explosion(tree_x[i], tree_y[i], 0xCD853FFF, 1fx, 40)
                            tree_amount = tree_amount - 1
                        end
                        return true
                    end)
                end
            end
            -- Code for detecting bullets for rocks.
            for i=1, rock_amount do
                if pewpew.entity_get_is_alive(rocks[i])then
                        pewpew.customizable_entity_set_weapon_collision_callback(rocks[i], function(entity_id, player_index, weapon_type)
                        if weapon_type == pewpew.WeaponType.BULLET and pewpew.entity_get_is_alive(entity_id) then
                        pewpew.create_explosion(rock_x[i], rock_y[i], 0x353535FF, 1fx, 15)
                        stone = stone + 1
                        money = money + 20
                        rock_uses[i] = rock_uses[i] + 1
                        end
                        -- If rock is attacked 5 times, destroy it.
                        if weapon_type == pewpew.WeaponType.BULLET and rock_uses[i] == 5 and pewpew.entity_get_is_alive(entity_id) then
                            --pewpew.customizable_entity_start_exploding(entity_id, 30)
                            pewpew.entity_destroy(entity_id)
                            pewpew.create_explosion(rock_x[i], rock_y[i], 0x353535FF, 1fx, 40)
                            rock_amount = rock_amount - 1
                        end
                        return true
                    end)
                end
            end
            if pewpew.entity_get_is_alive(plus1) then
                pewpew.customizable_entity_set_player_collision_callback(plus1, function(entity_id, player_index, ship_entity_id)
                    if money >= 1000 then
                        money = money - 1000
                        w = 2250fx
                        floating_message.new(x, y + 80fx, "Level area unlocked!", 1fx, 0xffffffff, 16)
                        pewpew.customizable_entity_start_spawning(border2, 90)
                        pewpew.customizable_entity_set_mesh(border2, "/dynamic/level_graphics.lua", 0)
                        pewpew.entity_destroy(plus1)
                    end
                end)
            end
            if pewpew.entity_get_is_alive(plus2) then
                pewpew.customizable_entity_set_player_collision_callback(plus2, function(entity_id, player_index, ship_entity_id)
                    if money >= 2000 then
                        money = money - 2000
                        w = 3250fx
                        floating_message.new(x, y + 80fx, "Level area unlocked!", 1fx, 0xffffffff, 16)
                        pewpew.customizable_entity_start_spawning(border3, 90)
                        pewpew.customizable_entity_set_mesh(border3, "/dynamic/level_graphics.lua", 0)
                        pewpew.entity_destroy(plus2)
                    end
                end)
            end
            if pewpew.entity_get_is_alive(plus3) then
                pewpew.customizable_entity_set_player_collision_callback(plus3, function(entity_id, player_index, ship_entity_id)
                    if money >= 3000 then
                        money = money - 3000
                        w = 4250fx
                        floating_message.new(x, y + 80fx, "Level area unlocked!", 1fx, 0xffffffff, 16)
                        pewpew.customizable_entity_start_spawning(border4, 90)
                        pewpew.customizable_entity_set_mesh(border4, "/dynamic/level_graphics.lua", 0)
                        pewpew.entity_destroy(plus3)
                    end
                end)
            end
            if pewpew.entity_get_is_alive(plus4) then
                pewpew.customizable_entity_set_player_collision_callback(plus4, function(entity_id, player_index, ship_entity_id)
                    if money >= 4000 then
                        money = money - 4000
                        w = 5250fx
                        floating_message.new(x, y + 80fx, "Level area unlocked!", 1fx, 0xffffffff, 16)
                        pewpew.customizable_entity_start_spawning(border5, 90)
                        pewpew.customizable_entity_set_mesh(border5, "/dynamic/level_graphics.lua", 0)
                        pewpew.entity_destroy(plus4)
                    end
                end)
            end
            if pewpew.entity_get_is_alive(plus5) then
                pewpew.customizable_entity_set_player_collision_callback(plus5, function(entity_id, player_index, ship_entity_id)
                    if money >= 5000 then
                        money = money - 5000
                        w = 6000fx
                        floating_message.new(x, y + 80fx, "Level area unlocked!", 1fx, 0xffffffff, 16)
                        pewpew.customizable_entity_start_spawning(border6, 90)
                        pewpew.customizable_entity_set_mesh(border6, "/dynamic/level_graphics.lua", 0)
                        pewpew.entity_destroy(plus5)
                    end
                end)
            end
            if tree_amount == 0 then
                generatetrees(0fx, 0fx, w-250fx, h)
            end
            if rock_amount == 0 then
                generaterocks(0fx, 0fx, w-250fx, h)
            end
        else
            pewpew.stop_game()
        end
    end)