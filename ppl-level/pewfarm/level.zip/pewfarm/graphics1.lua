meshes = {{
  vertexes = {{0,0}, {0,1000}, {250,1000}, {250,0}},
  segments = {{0,1,2,3,0}},
  colors = {0xff0000ff, 0xff0000ff, 0xff0000ff, 0xff0000ff}
}}
