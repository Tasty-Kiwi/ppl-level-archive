local angle_helpers = require("/dynamic/helpers/angle_helpers.lua")
local player_helpers = require("/dynamic/helpers/player_helpers.lua")

local floating_message = require("/dynamic/helpers/floating_message.lua")
local shield_box = require("/dynamic/helpers/boxes/shield_box.lua")
local cannon_box = require("/dynamic/helpers/boxes/cannon_box.lua")

local width = 900fx
local height = 900fx
pewpew.set_level_size(width, height)

local background1 = pewpew.new_customizable_entity(300fx, 300fx)
pewpew.customizable_entity_set_mesh(background1, "/dynamic/assets/graphics.lua", 0)
pewpew.customizable_entity_set_mesh_color(background1, 0xff0000ff)

local background2 = pewpew.new_customizable_entity(0fx, 0fx)
pewpew.customizable_entity_set_mesh(background2, "/dynamic/assets/graphics.lua", 0)
pewpew.customizable_entity_set_mesh_color(background2, 0x00ffc8ff)

local background3 = pewpew.new_customizable_entity(0fx, 600fx)
pewpew.customizable_entity_set_mesh(background3, "/dynamic/assets/graphics.lua", 0)
pewpew.customizable_entity_set_mesh_color(background3, 0xff2986ff)

local background4 = pewpew.new_customizable_entity(600fx, 600fx)
pewpew.customizable_entity_set_mesh(background4, "/dynamic/assets/graphics.lua", 0)
pewpew.customizable_entity_set_mesh_color(background4, 0x00ff00ff)

local background5 = pewpew.new_customizable_entity(600fx, 0fx)
pewpew.customizable_entity_set_mesh(background5, "/dynamic/assets/graphics.lua", 0)
pewpew.customizable_entity_set_mesh_color(background5, 0xff6000ff)

--1st box
pewpew.add_wall(300fx, 300fx, 300fx, 600fx)
pewpew.add_wall(300fx, 600fx, 600fx, 600fx)
pewpew.add_wall(600fx, 600fx, 600fx, 300fx)
pewpew.add_wall(300fx, 300fx, 600fx, 300fx)

--2nd box
pewpew.add_wall(0fx, 600fx, 300fx, 600fx)
pewpew.add_wall(300fx, 600fx, 300fx, 900fx)

--3rd box
pewpew.add_wall(-1fx, 300fx, 301fx, 300fx)
pewpew.add_wall(300fx, 300fx, 300fx, 0fx)

--4th box
pewpew.add_wall(600fx, 600fx, 600fx, 900fx)
pewpew.add_wall(600fx, 600fx, 900fx, 600fx)

--5th box
pewpew.add_wall(600fx, -1fx, 600fx, 301fx)
pewpew.add_wall(300fx, 300fx, 900fx, 300fx)

-- Create players
local weapon_config = {frequency = pewpew.CannonFrequency.FREQ_2, cannon = pewpew.CannonType.HEMISPHERE}
local ship1 = player_helpers.new_player_ship(width / 2fx, height / 2fx, 0)
local ship2 = player_helpers.new_player_ship(150fx, 150fx, 0)
local ship3 = player_helpers.new_player_ship(150fx, 750fx, 0)
local ship4 = player_helpers.new_player_ship(750fx, 750fx, 0)
local ship5 = player_helpers.new_player_ship(750fx, 150fx, 0)

pewpew.configure_player(0, {camera_distance = -1000fx, shield = 20})
pewpew.configure_player_ship_weapon(ship1, weapon_config)
pewpew.configure_player_ship_weapon(ship2, weapon_config)
pewpew.configure_player_ship_weapon(ship3, weapon_config)
pewpew.configure_player_ship_weapon(ship4, weapon_config)
pewpew.configure_player_ship_weapon(ship5, weapon_config)

local function random_position()
  return fmath.random_fixedpoint(10fx, width-10fx), fmath.random_fixedpoint(10fx, height-10fx)
end

local time = 0
pewpew.add_update_callback(
    function()
      if pewpew.get_player_configuration(0)["has_lost"] then
        pewpew.stop_game()
        if pewpew.get_entity_count(11) > 0 then
          pewpew.entity_destroy(ship1)
          pewpew.entity_destroy(ship2)
          pewpew.entity_destroy(ship3)
          pewpew.entity_destroy(ship4)
          pewpew.entity_destroy(ship5)
        end
      else
        pewpew.increase_score_of_player(0, 10)
        time = time + 1
        if time % 75 == 0 then
          pewpew.new_mothership( 50fx, fmath.random_fixedpoint(0fx, 300fx), 4, 0fx)
          pewpew.new_mothership( 50fx, fmath.random_fixedpoint(600fx, 900fx), 0, 0fx)
          pewpew.new_mothership(350fx, fmath.random_fixedpoint(300fx, 600fx), 1, 0fx)
          pewpew.new_mothership(650fx, fmath.random_fixedpoint(600fx, 900fx), 3, 0fx)
          pewpew.new_mothership(650fx, fmath.random_fixedpoint(0fx, 300fx), 2, 0fx)
        end
      end
    end)
